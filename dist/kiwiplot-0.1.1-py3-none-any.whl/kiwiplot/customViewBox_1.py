'''
Reference:
https://www.mail-archive.com/pyqtgraph@googlegroups.com/msg00908.html
'''
import pyqtgraph as pg
from .pplogger import *
logger = logging.getLogger('kiwiplot.' + __name__) 

class CustomViewbox(pg.ViewBox):
    def __init__(self, parent=None):
        super(CustomViewbox, self).__init__(parent)
        self.menu = pg.ViewBoxMenu.ViewBoxMenu(self)
        self.menuUpdate = True

    def getMenu(self, event=None):
        logger.debug('Getting menu')

