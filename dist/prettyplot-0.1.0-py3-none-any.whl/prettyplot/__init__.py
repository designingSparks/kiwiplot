from .prettyplot import PrettyPlot
from .prettyplot import plotstyle
from .qtWrapper import *